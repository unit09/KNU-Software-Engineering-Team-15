package System_UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JList;

public class Main_UI extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_UI frame = new Main_UI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main_UI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 602, 406);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
		
		JTabbedPane Tab = new JTabbedPane(JTabbedPane.LEFT);
		
		//�α��� �ϸ� ������ ȭ��
		JPanel main_panel = new JPanel();
		main_panel.setLayout(null);
		Tab.addTab("����ȭ��", main_panel);
		
		//�׳� ���� ����� �װ���
		JLabel lblMainDisplay = new JLabel("Main Display");
		lblMainDisplay.setBounds(133, 92, 150, 15);
		main_panel.add(lblMainDisplay);
		
		//�������� ���� ��ȸ�� �� ó���ϴ� ��
		JPanel sub1_panel = new JPanel();
		sub1_panel.setLayout(null);
		Tab.addTab("��������", sub1_panel);
		
		//����� DB�κ��� ��ü list�����ϸ� �� https://blog.naver.com/dyno_tyno/221404766709
		String[] gonggolist = 
			{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", 
					"11", "12", "13", "11", "12", "13", "11", "12", "13"};
		JList<String> list = new JList<String>(gonggolist);
		JScrollPane ScrollList = new JScrollPane(list);
		ScrollList.setBounds(55, 55, 259, 233);
		sub1_panel.add(ScrollList);
		
		//�л��� ��� ���� ���� �ʿ�
		JPanel sub2_panel = new JPanel();
		sub2_panel.setLayout(null);
		Tab.addTab("�̼����� ����", sub2_panel);
		
		
		JPanel sub3_panel = new JPanel();
		sub3_panel.setLayout(null);
		Tab.addTab("33", sub3_panel);
		
		
		JPanel Question_panel = new JPanel();
		Question_panel.setLayout(null);
		Tab.addTab("�����Խ���", Question_panel);
		contentPane.add(Tab);
		
	}
}
